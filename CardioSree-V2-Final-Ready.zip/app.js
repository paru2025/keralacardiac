// CardioSree V2 - Core Logic
// Handles localization, profile management, daily logs, rehab tracking, and AI insights

// Translation Dictionary
const translations = {
    'en': {
        'welcome': 'Hello, ',
        'status_check': 'Your Heart Health Today',
        'status_excellent': 'Excellent!',
        'status_warning': 'Attention Needed',
        'status_danger': 'High Risk!',
        'keep_it_up': 'Great job. Keep it up.',
        'check_symptoms': 'Monitor your symptoms closely.',
        'seek_help': 'Please consult doctor immediately.',
        'help_now': 'HELP NOW',
        'todays_vitals': "Today's Vitals",
        'log_vitals': 'Add Vitals',
        'my_care_plan': 'My Care Plan',
        'exercises': 'Exercises',
        'diet_plan': 'Diet Plan',
        'coach_connect': 'Talk to Doctor',
        'medicines': 'Medicines',
        'daily_tip': "Today's Tip",
        'tip_content': 'Reduce salt intake. Walk for 30 mins daily.',
        'nav_home': 'Home',
        'nav_rehab': 'Rehab',
        'nav_profile': 'Profile',
        'diet_title': 'Heart Healthy Diet',
        'diet_subtitle': 'Our Traditional Foods',
        'eat_plenty': 'Safe to Eat',
        'eat_moderate': 'Eat in Moderation',
        'avoid_strict': 'Avoid Strictly',
        'portion_guide': 'Watch Portions',
        'rehab_title': 'Rehab Exercises',
        'rehab_subtitle': 'Phase-wise Exercises',
        'phase_1': 'Phase 1: Early',
        'phase_1_desc': 'First 2 weeks after discharge.',
        'gentle_walk': 'Gentle Walking',
        'chair_yoga': 'Chair Exercises',
        'start': 'Start',
        'phase_2': 'Phase 2: Progress',
        'phase_2_desc': '2 weeks to 3 months.',
        'brisk_walk': 'Brisk Walking',
        'stop_signs': 'Caution!',
        'stop_warning': 'Stop immediately if you feel chest pain, breathlessness, or dizziness.',
        'coach_title': 'Talk to Coach',
        'coach_subtitle': 'Seek Expert Advice',
        'call_now': 'Call Coach',
        'chat_now': 'WhatsApp Chat',
        'book_appointment': 'Book Appointment',
        'select_date': 'Select Date',
        'select_time': 'Time',
        'confirm_booking': 'Confirm',
        'profile_title': 'My Profile',
        'name': 'Name',
        'age': 'Age',
        'condition': 'Condition',
        'reminders': 'Reminders',
        'medicine_reminder': 'Medicine',
        'walk_reminder': 'Walking',
        'water_reminder': 'Water',
        'logout': 'Logout',
        'get_started': 'Get Started',
        // Onboarding
        'setup_profile': 'Setup Profile',
        'setup_desc': 'Let us know you better',
        'lbl_name': 'Name / Nickname',
        'lbl_age': 'Age',
        'lbl_gender': 'Gender',
        'lbl_district': 'District',
        'lbl_language': 'Preferred Language',
        'lbl_condition': 'Cardiac Condition',
        'lbl_emergency': 'Emergency Contact Number',
        'btn_save_profile': 'Start Journey',
        'gender_male': 'Male',
        'gender_female': 'Female',
        'gender_other': 'Other',
        'cond_pci': 'Post-Angioplasty (PCI)',
        'cond_cabg': 'Post-Bypass (CABG)',
        'cond_high_risk': 'High Risk',
        'cond_prevention': 'Prevention',
        // Vitals
        'vitals_title': 'Daily Vitals',
        'vitals_desc': 'Log your health metrics',
        'lbl_bp': 'Blood Pressure (BP)',
        'lbl_heart_activity': 'Heart & Activity',
        'lbl_hr': 'Heart Rate (BPM)',
        'lbl_steps': 'Walking (Steps / Mins)',
        'lbl_symptoms': 'Symptoms',
        'symptoms_desc': 'Are you experiencing any of these?',
        'sym_chest': 'Chest Pain / Discomfort',
        'sym_breath': 'Breathlessness',
        'sym_dizzy': 'Dizziness',
        'lbl_rest': 'Rest & Stress',
        'lbl_sleep': 'Sleep (Hours)',
        'lbl_stress': 'Stress Level',
        'btn_save_vitals': 'Save Record',
        // Activity Log
        'current_phase': 'Current Rehab Phase',
        'log_activity': "Today's Activity",
        'activity_type': 'Type',
        'duration_mins': 'Duration (Mins)',
        'mark_complete': 'Mark Complete ✅',
        'act_walking': 'Walking',
        'act_breathing': 'Breathing',
        'act_yoga': 'Yoga',
        'recent_activity': 'Recent Activities',
        'no_activity': 'No activities recorded yet.',
        'phase_1_title': 'Phase 1 Plan',
        'phase_2_title': 'Phase 2 Plan',
        'phase_3_title': 'Maintenance Plan',
        'task_walk_5': 'Walk 5 mins inside house',
        'task_breath': 'Deep breathing (Pranayama)',
        'task_walk_20': 'Brisk walk 20-30 mins',
        'task_yoga': 'Light Yoga / Stretching',
        'task_walk_45': 'Walk/Jog 45 mins',
        'task_strength': 'Light weights (if approved)',
        'phase_3': 'Maintenance',
        // Alerts
        'alert_history': 'Alert History',
        'risk_trend': 'Risk Trend Score',
        'view_history': 'View History',
        'no_alerts': 'No alerts recorded.',
        'back_to_dashboard': 'Back to Dashboard',
        
        // New Modules
        'lbl_history': 'Medical History',
        'hist_mi': 'Heart Attack (MI)',
        'hist_surgery': 'Heart Surgery',
        'hist_diabetes': 'Diabetes',
        'hist_bp': 'Hypertension (BP)',
        'lbl_meds': 'Current Medications',
        'lbl_activity': 'Baseline Activity Level',
        'act_sedentary': 'Sedentary (Little/No Exercise)',
        'act_moderate': 'Moderate (Light Exercise)',
        'act_active': 'Active (Regular Exercise)',
        'lbl_doctor': 'Primary Clinician',
        'lbl_metabolic': 'Weight & Blood Sugar',
        'reminders_title': 'Medications & Appointments',
        'tab_meds': 'Medications',
        'tab_appts': 'Appointments',
        'todays_meds': "Today's Medicines",
        'add_med': '+ Add Medicine',
        'refill_alert': 'Refill Alert',
        'refill_msg': 'Your Aspirin stock is low (5 days left).',
        'upcoming_appts': 'Upcoming Appointments',
        'book_new': 'Book New',
        'edu_title': 'Heart School',
        'edu_subtitle': 'Learn to live better',
        'edu_basics': 'Heart Basics',
        'lesson_heart_1': 'How your heart works',
        'lesson_warning': 'Warning Signs',
        'edu_diet': 'Diet & Nutrition',
        'tap_to_view': 'Tap to view full guide',
        'edu_lifestyle': 'Lifestyle',
        'lesson_smoking': 'Quitting Smoking',
        'lesson_stress': 'Managing Stress',
        'lesson_sleep': 'Sleep Hygiene',
        'support_title': 'Support & Motivation',
        'quote_title': 'Thought of the Day',
        'mood_check': 'How are you feeling today?',
        'mindfulness_title': 'Mindfulness',
        'audio_relax': '5 Min Relaxation',
        'achievements_title': 'Your Progress',
        'nav_edu': 'Education',
        'nav_support': 'Support',
        'nav_meds': 'Meds'
    },
    'ml': {
        'welcome': 'നമസ്കാരം, ',
        'status_check': 'ഇന്നത്തെ നിങ്ങളുടെ ഹൃദയ ആരോഗ്യം',
        'status_excellent': 'മികച്ച നില!',
        'status_warning': 'ശ്രദ്ധിക്കുക',
        'status_danger': 'അപകട സാധ്യത!',
        'keep_it_up': 'വളരെ നല്ലത്. ഇതുപോലെ തുടരുക.',
        'check_symptoms': 'ലക്ഷണങ്ങൾ ശ്രദ്ധിക്കുക. വിശ്രമിക്കുക.',
        'seek_help': 'ഉടൻ ഡോക്ടറെ കാണുക.',
        'help_now': 'അടിയന്തര സഹായം',
        'todays_vitals': 'ഇന്നത്തെ അളവുകൾ',
        'log_vitals': 'അളവുകൾ ചേർക്കുക',
        'my_care_plan': 'എന്റെ പരിചരണ പദ്ധതി',
        'exercises': 'വ്യായാമ മുറകൾ',
        'diet_plan': 'ഭക്ഷണ ക്രമം',
        'coach_connect': 'കാർഡിയാക് കോച്ച്',
        'medicines': 'മരുന്നുകൾ',
        'daily_tip': 'ഇന്നത്തെ അറിവ്',
        'tip_content': 'ഉപ്പിന്റെ ഉപയോഗം കുറയ്ക്കുക. ദിവസവും 30 മിനിറ്റ് നടക്കുക.',
        'nav_home': 'Home',
        'nav_rehab': 'Rehab',
        'nav_profile': 'Profile',
        'diet_title': 'ഹൃദയ സൗഹൃദ ഭക്ഷണം',
        'diet_subtitle': 'നമ്മുടെ നാടൻ ഭക്ഷണ രീതികൾ',
        'eat_plenty': 'ധൈര്യമായി കഴിക്കാം',
        'eat_moderate': 'മിതമായി കഴിക്കുക',
        'avoid_strict': 'പൂർണ്ണമായും ഒഴിവാക്കുക',
        'portion_guide': 'അളവുകൾ ശ്രദ്ധിക്കുക',
        'rehab_title': 'പുനരധിവാസ വ്യായാമങ്ങൾ',
        'rehab_subtitle': 'ഘട്ടം തിരിച്ചുള്ള വ്യായാമ മുറകൾ',
        'phase_1': 'ഘട്ടം 1: ആദ്യകാലം',
        'phase_1_desc': 'ആശുപത്രി വിട്ടതിന് ശേഷമുള്ള ആദ്യ 2 ആഴ്ചകൾ.',
        'gentle_walk': 'സൗമ്യമായ നടത്തം',
        'chair_yoga': 'കസേര വ്യായാമങ്ങൾ',
        'start': 'തുടങ്ങുക',
        'phase_2': 'ഘട്ടം 2: പുരോഗതി',
        'phase_2_desc': '2 ആഴ്ച മുതൽ 3 മാസം വരെ.',
        'brisk_walk': 'വേഗത്തിലുള്ള നടത്തം',
        'stop_signs': 'ശ്രദ്ധിക്കുക!',
        'stop_warning': 'നെഞ്ചുവേദന, കിതപ്പ്, തലകറക്കം എന്നിവ അനുഭവപ്പെട്ടാൽ ഉടൻ വ്യായാമം നിർത്തി വിശ്രമിക്കുക.',
        'coach_title': 'കോച്ചുമായി സംസാരിക്കുക',
        'coach_subtitle': 'വിദഗ്ദ്ധ ഉപദേശം തേടാം',
        'call_now': 'കോച്ചിനെ വിളിക്കുക',
        'chat_now': 'വാട്സാപ്പിൽ ചാറ്റ് ചെയ്യുക',
        'book_appointment': 'അപ്പോയിന്റ്മെന്റ് എടുക്കുക',
        'select_date': 'തിയതി തിരഞ്ഞെടുക്കുക',
        'select_time': 'സമയം',
        'confirm_booking': 'സ്ഥിരീകരിക്കുക',
        'profile_title': 'എന്റെ വിവരങ്ങൾ',
        'name': 'പേര്',
        'age': 'വയസ്സ്',
        'condition': 'അസുഖം',
        'reminders': 'ഓർമ്മപ്പെടുത്തലുകൾ',
        'medicine_reminder': 'മരുന്ന് കഴിക്കാൻ',
        'walk_reminder': 'നടക്കാൻ',
        'water_reminder': 'വെള്ളം കുടിക്കാൻ',
        'logout': 'ലോഗൗട്ട്',
        'get_started': 'തുടങ്ങാം',
        // Onboarding
        'setup_profile': 'പ്രൊഫൈൽ തയ്യാറാക്കാം',
        'setup_desc': 'നിങ്ങളെക്കുറിച്ച് കൂടുതൽ അറിയാൻ',
        'lbl_name': 'പേര് / വിളിപ്പേര്',
        'lbl_age': 'വയസ്സ്',
        'lbl_gender': 'ലിംഗം',
        'lbl_district': 'ജില്ല',
        'lbl_language': 'ഭാഷ',
        'lbl_condition': 'ഹൃദയ അവസ്ഥ',
        'lbl_emergency': 'അടിയന്തര നമ്പർ',
        'btn_save_profile': 'യാത്ര തുടങ്ങാം',
        'gender_male': 'പുരുഷൻ',
        'gender_female': 'സ്ത്രീ',
        'gender_other': 'മറ്റുള്ളവർ',
        'cond_pci': 'ആൻജിയോപ്ലാസ്റ്റി കഴിഞ്ഞവർ (Post-PCI)',
        'cond_cabg': 'ബൈപാസ് കഴിഞ്ഞവർ (Post-CABG)',
        'cond_high_risk': 'ഉയർന്ന സാധ്യത (High Risk)',
        'cond_prevention': 'പ്രതിരോധം (Prevention)',
        // Vitals
        'vitals_title': 'ഇന്നത്തെ കണക്കുകൾ',
        'vitals_desc': 'നിങ്ങളുടെ ആരോഗ്യം രേഖപ്പെടുത്തുക',
        'lbl_bp': 'രക്തസമ്മർദ്ദം (BP)',
        'lbl_heart_activity': 'ഹൃദയവും നടത്തവും',
        'lbl_hr': 'ഹൃദയമിടിപ്പ് (BPM)',
        'lbl_steps': 'നടത്തം (Steps / Mins)',
        'lbl_symptoms': 'ലക്ഷണങ്ങൾ',
        'symptoms_desc': 'താഴെ പറയുന്നവ അനുഭവപ്പെടുന്നുണ്ടോ?',
        'sym_chest': 'നെഞ്ചുവേദന / അസ്വസ്ഥത',
        'sym_breath': 'ശ്വാസംമുട്ടൽ',
        'sym_dizzy': 'തലകറക്കം',
        'lbl_rest': 'വിശ്രമം',
        'lbl_sleep': 'ഉറക്കം (മണിക്കൂർ)',
        'lbl_stress': 'മാനസിക സമ്മർദ്ദം (Stress)',
        'btn_save_vitals': 'രേഖപ്പെടുത്തുക',
        // Activity Log
        'current_phase': 'ഇപ്പോഴത്തെ ഘട്ടം',
        'log_activity': 'ഇന്നത്തെ വ്യായാമം',
        'activity_type': 'ഇനം',
        'duration_mins': 'സമയം (മിനിറ്റ്)',
        'mark_complete': 'പൂർത്തിയായി ✅',
        'act_walking': 'നടത്തം (Walking)',
        'act_breathing': 'ശ്വാസക്രിയ (Breathing)',
        'act_yoga': 'യോഗ (Yoga)',
        'recent_activity': 'കഴിഞ്ഞ വ്യായാമങ്ങൾ',
        'no_activity': 'വ്യായാമങ്ങൾ ഒന്നും രേഖപ്പെടുത്തിയിട്ടില്ല.',
        'phase_1_title': 'Phase 1 Plan',
        'phase_2_title': 'Phase 2 Plan',
        'phase_3_title': 'Maintenance Plan',
        'task_walk_5': 'വീടിനുള്ളിൽ 5 മിനിറ്റ് നടക്കുക',
        'task_breath': 'ദീർഘശ്വാസം എടുക്കുക (Pranayama)',
        'task_walk_20': '20-30 മിനിറ്റ് വേഗത്തിൽ നടക്കുക',
        'task_yoga': 'ലഘുവായ യോഗ / സ്ട്രെച്ചിംഗ്',
        'task_walk_45': '45 മിനിറ്റ് നടക്കുക / ജോഗിംഗ്',
        'task_strength': 'ലഘുവായ ഭാരം ഉയർത്താം',
        'phase_3': 'Maintenance',
        // Alerts
        'alert_history': 'അലേർട്ട് ചരിത്രം',
        'risk_trend': 'റിസ്ക് ട്രെൻഡ് സ്കോർ',
        'view_history': 'ചരിത്രം കാണുക',
        'no_alerts': 'അലേർട്ടുകൾ ഒന്നുമില്ല.',
        'back_to_dashboard': 'ഡാഷ്‌ബോർഡിലേക്ക്',

        // New Modules
        'lbl_history': 'മറ്റ് അസുഖങ്ങൾ',
        'hist_mi': 'ഹൃദയാഘാതം (Heart Attack)',
        'hist_surgery': 'ശസ്ത്രക്രിയ (Surgery)',
        'hist_diabetes': 'പ്രമേഹം (Diabetes)',
        'hist_bp': 'രക്തസമ്മർദ്ദം (BP)',
        'lbl_meds': 'കഴിക്കുന്ന മരുന്നുകൾ',
        'lbl_activity': 'ശാരീരിക അധ്വാനം',
        'act_sedentary': 'കുറഞ്ഞ അധ്വാനം (Sedentary)',
        'act_moderate': 'മിതമായ അധ്വാനം (Moderate)',
        'act_active': 'നല്ല അധ്വാനം (Active)',
        'lbl_doctor': 'ഡോക്ടറുടെ വിവരങ്ങൾ',
        'lbl_metabolic': 'ഭാരവും ഷുഗറും',
        'reminders_title': 'മരുന്നുകളും അപ്പോയിന്റ്മെന്റുകളും',
        'tab_meds': 'മരുന്നുകൾ',
        'tab_appts': 'അപ്പോയിന്റ്മെന്റ്',
        'todays_meds': 'ഇന്നത്തെ മരുന്നുകൾ',
        'add_med': '+ മരുന്ന് ചേർക്കുക',
        'refill_alert': 'മരുന്ന് തീരാറായി',
        'refill_msg': 'നിങ്ങളുടെ ആസ്പിരിൻ തീരാറായി (5 ദിവസം കൂടി).',
        'upcoming_appts': 'അടുത്ത അപ്പോയിന്റ്മെന്റ്',
        'book_new': 'പുതിയത് ബുക്ക് ചെയ്യുക',
        'edu_title': 'ഹൃദയ പാഠശാല',
        'edu_subtitle': 'ആരോഗ്യമുള്ള ജീവിതത്തിന്',
        'edu_basics': 'അടിസ്ഥാന വിവരങ്ങൾ',
        'lesson_heart_1': 'ഹൃദയം എങ്ങനെ പ്രവർത്തിക്കുന്നു',
        'lesson_warning': 'അപകട സൂചനകൾ',
        'edu_diet': 'ഭക്ഷണ ക്രമം',
        'tap_to_view': 'കൂടുതൽ അറിയാൻ',
        'edu_lifestyle': 'ജീവിതശൈലി',
        'lesson_smoking': 'പുകവലി നിർത്താം',
        'lesson_stress': 'മാനസിക സമ്മർദ്ദം കുറയ്ക്കാം',
        'lesson_sleep': 'നല്ല ഉറക്കം',
        'support_title': 'പിന്തുണയും പ്രചോദനവും',
        'quote_title': 'ഇന്നത്തെ ചിന്ത',
        'mood_check': 'ഇന്ന് നിങ്ങൾക്ക് എങ്ങനെയുണ്ട്?',
        'mindfulness_title': 'ധ്യാനം / വിശ്രമം',
        'audio_relax': '5 മിനിറ്റ് വിശ്രമം',
        'achievements_title': 'നിങ്ങളുടെ നേട്ടങ്ങൾ',
        'nav_edu': 'പഠനം',
        'nav_support': 'പിന്തുണ',
        'nav_meds': 'മരുന്നുകൾ'
    }
};

// Current Language State
let currentLang = localStorage.getItem('cardiosree_lang') || 'ml';

// DOM Elements
const langToggleBtn = document.getElementById('langToggle');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    updateLanguage(currentLang);
    
    // Check if user is logged in for protected pages
    checkAuth();

    if(langToggleBtn) {
        langToggleBtn.textContent = currentLang === 'ml' ? 'ENG' : 'മലയാളം';
        langToggleBtn.addEventListener('click', toggleLanguage);
    }
});

// Check Auth & Redirect
function checkAuth() {
    const page = document.body.getAttribute('data-page');
    const userProfile = localStorage.getItem('cardiosree_profile');

    // Pages that don't require auth
    if (page === 'index' || page === 'onboarding') {
        return; 
    }

    // Protected pages: redirect if no profile
    if (!userProfile) {
        window.location.href = 'index.html';
        return;
    }

    // If dashboard, load user name and vitals
    if (page === 'dashboard') {
        const profile = JSON.parse(userProfile);
        const welcomeEl = document.querySelector('[data-i18n="welcome"]');
        if (welcomeEl) {
            const welcomeText = translations[currentLang]['welcome'];
            welcomeEl.textContent = welcomeText + profile.name;
        }
        updateDashboardVitals();
    }

    // If profile page, load user data
    if (page === 'profile') {
        loadProfileData();
    }

    // Check if alerts page, load alert history
    if (page === 'alerts') {
        loadAlertHistory();
    }
}

// === EXERCISE & REHAB DATA ===
const rehabPlans = {
    'phase1': {
        weeks: 'Week 1-2',
        title: 'Phase 1: Early Recovery (ആദ്യ ഘട്ടം)',
        desc: 'Focus: Gentle movement & Breathing',
        routine: [
            { type: 'Warm-up', items: ['Ankle Pumps (കണങ്കാൽ ചലനം)', 'Shoulder Shrugs (തോളുകൾ ഉയർത്തുക)', 'Neck Rotation (കഴുത്തു തിരിക്കൽ)'] },
            { type: 'Main', items: ['Walk inside house 5-10 mins (വീടിനുള്ളിൽ നടക്കുക)', 'Chair Yoga (കസേര വ്യായാമങ്ങൾ)'] },
            { type: 'Cool-down', items: ['Deep Breathing - Pranayama (ദീർഘശ്വാസം)', 'Shavasana (ശവാസനം - Rest)'] }
        ]
    },
    'phase2': {
        weeks: 'Week 3-12',
        title: 'Phase 2: Building Strength (രണ്ടാം ഘട്ടം)',
        desc: 'Focus: Stamina & Flexibility',
        routine: [
            { type: 'Warm-up', items: ['Arm Circles (കൈകൾ കറക്കുക)', 'Marching in place (നിന്നുകൊണ്ട് നടക്കുക)'] },
            { type: 'Main', items: ['Brisk Walk 20-30 mins (വേഗത്തിൽ നടക്കുക)', 'Tadasana (Mountain Pose)', 'Vrikshasana (Tree Pose - with support)'] },
            { type: 'Cool-down', items: ['Slow Walking 5 mins', 'Stretching (ശരീരം വലിയ്ക്കൽ)'] }
        ]
    },
    'maintenance': {
        weeks: 'Lifetime',
        title: 'Phase 3: Maintenance (തുടർ ഘട്ടം)',
        desc: 'Focus: Heart Health for Life',
        routine: [
            { type: 'Warm-up', items: ['Full Body Stretch', 'Spot Jogging (സാവധാനം ഓടുക)'] },
            { type: 'Main', items: ['Walk/Jog 45 mins', 'Surya Namaskar (സൂര്യ നമസ്കാരം - 3 rounds)', 'Light Weights (500g)'] },
            { type: 'Cool-down', items: ['Meditation (ധ്യാനം)', 'Relaxation'] }
        ]
    }
};

// === MEDICINE DATABASE ===
const medicineDB = [
    { category: 'Cholesterol (കൊളസ്ട്രോൾ)', meds: [
        { name: 'Atorvastatin (Atorva/Stator)', dose: '10-40mg', use: 'Lowers bad cholesterol', side_effect: 'Muscle pain, fatigue' },
        { name: 'Rosuvastatin (Rosuvas)', dose: '5-20mg', use: 'Prevents plaque buildup', side_effect: 'Headache, nausea' }
    ]},
    { category: 'Diabetes (പ്രമേഹം)', meds: [
        { name: 'Metformin (Glycomet)', dose: '500-1000mg', use: 'Controls blood sugar', side_effect: 'Stomach upset' },
        { name: 'Teneligliptin', dose: '20mg', use: 'Increases insulin', side_effect: 'Low sugar (Hypo)' }
    ]},
    { category: 'Blood Pressure (രക്തസമ്മർദ്ദം)', meds: [
        { name: 'Telmisartan (Telma)', dose: '40-80mg', use: 'Relaxes blood vessels', side_effect: 'Dizziness' },
        { name: 'Amlodipine', dose: '5-10mg', use: 'Lowers BP', side_effect: 'Swelling in feet' }
    ]},
    { category: 'Anti-platelets (രക്തം കട്ടപിടിക്കാതിരിക്കാൻ)', meds: [
        { name: 'Aspirin (Ecosprin)', dose: '75-150mg', use: 'Prevents clots', side_effect: 'Acidity, bleeding' },
        { name: 'Clopidogrel', dose: '75mg', use: 'Blood thinner', side_effect: 'Bruising' }
    ]}
];

// Toggle Language Function
function toggleLanguage() {
    currentLang = currentLang === 'ml' ? 'en' : 'ml';
    localStorage.setItem('cardiosree_lang', currentLang);
    if(langToggleBtn) langToggleBtn.textContent = currentLang === 'ml' ? 'ENG' : 'മലയാളം';
    updateLanguage(currentLang);
}

// Update Text Content
function updateLanguage(lang) {
    document.documentElement.lang = lang;
    
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });

    // Special case updates
    const page = document.body.getAttribute('data-page');
    if (page === 'dashboard') {
        const userProfile = localStorage.getItem('cardiosree_profile');
        if (userProfile) {
            const profile = JSON.parse(userProfile);
            const welcomeEl = document.querySelector('[data-i18n="welcome"]');
            if (welcomeEl) {
                welcomeEl.textContent = translations[lang]['welcome'] + profile.name;
            }
        }
        updateDashboardVitals();
    }
}

// Save Profile (Onboarding)
function saveProfile() {
    const name = document.getElementById('userName').value;
    const age = document.getElementById('userAge').value;
    const gender = document.getElementById('userGender').value;
    const district = document.getElementById('userDistrict').value;
    const language = document.getElementById('userLanguage').value;
    const condition = document.getElementById('userCondition').value;
    const emergency = document.getElementById('userEmergency').value;
    
    // New Fields
    const histMI = document.getElementById('histMI').checked;
    const histSurgery = document.getElementById('histSurgery').checked;
    const histDiabetes = document.getElementById('histDiabetes').checked;
    const histBP = document.getElementById('histBP').checked;
    const medications = document.getElementById('userMeds').value;
    const activityLevel = document.getElementById('userActivity').value;
    const docName = document.getElementById('docName').value;
    const docHospital = document.getElementById('docHospital').value;

    if (!name || !age || !gender || !district || !condition || !emergency) {
        alert('Please fill all required fields');
        return;
    }

    const profile = {
        id: 'CS-' + Date.now().toString().slice(-6),
        name: name,
        age: age,
        gender: gender,
        district: district,
        language: language,
        condition: condition,
        emergency: emergency,
        medicalHistory: {
            mi: histMI,
            surgery: histSurgery,
            diabetes: histDiabetes,
            hypertension: histBP
        },
        medications: medications,
        activityLevel: activityLevel,
        clinician: {
            name: docName,
            hospital: docHospital
        },
        rehabPhase: 'phase1', // Default start
        joinedDate: new Date().toISOString()
    };

    localStorage.setItem('cardiosree_profile', JSON.stringify(profile));
    localStorage.setItem('cardiosree_lang', language);
    
    window.location.href = 'dashboard.html';
}

// Load Profile Data (Profile Page)
function loadProfileData() {
    const userProfile = localStorage.getItem('cardiosree_profile');
    if (!userProfile) return;

    const profile = JSON.parse(userProfile);
    
    const setVal = (selector, val) => {
        const el = document.querySelector(selector);
        if (el) el.value = val;
    };

    setVal('#pName', profile.name);
    setVal('#pAge', profile.age);
    setVal('#pCondition', profile.condition);
    setVal('#pID', profile.id);
    setVal('#pPhase', profile.rehabPhase || 'Phase 1'); // Show phase

    // Load Activity Logs
    const activities = JSON.parse(localStorage.getItem('cardiosree_activities') || '[]');
    const logContainer = document.getElementById('activityLogList');
    
    if (activities.length > 0 && logContainer) {
        logContainer.innerHTML = '';
        // Show last 5 activities
        activities.slice(-5).reverse().forEach(act => {
            const date = new Date(act.timestamp).toLocaleDateString();
            const div = document.createElement('div');
            div.style.borderBottom = '1px solid #eee';
            div.style.padding = '8px 0';
            div.innerHTML = `
                <div style="display:flex; justify-content:space-between;">
                    <strong>${act.type.toUpperCase()}</strong>
                    <span style="color:#666;">${date}</span>
                </div>
                <div style="font-size:14px;">${act.duration} mins</div>
            `;
            logContainer.appendChild(div);
        });
    }
}

// Save Daily Vitals
function saveVitals() {
    const bpSys = document.getElementById('bpSys').value;
    const bpDia = document.getElementById('bpDia').value;
    const heartRate = document.getElementById('heartRate').value;
    const steps = document.getElementById('steps').value;
    const sleep = document.getElementById('sleepHours').value;
    const stress = document.getElementById('stressLevel').value;
    
    // New Fields
    const weight = document.getElementById('weight').value;
    const sugar = document.getElementById('sugar').value;

    const symChest = document.getElementById('symChest').checked;
    const symBreath = document.getElementById('symBreath').checked;
    const symDizzy = document.getElementById('symDizzy').checked;

    const timestamp = new Date().toISOString();

    // Calculate Heart Score
    let score = 100;
    let status = 'excellent';
    let alertReason = [];
    
    // Danger Signs (Symptoms)
    if (symChest || symBreath || symDizzy) {
        score -= 40;
        status = 'danger';
        if(symChest) alertReason.push('Chest Pain');
        if(symBreath) alertReason.push('Breathlessness');
        if(symDizzy) alertReason.push('Dizziness');
    }
    
    // BP Logic (High BP warning)
    if (bpSys > 140 || bpDia > 90) {
        score -= 10;
        if(status !== 'danger') status = 'warning';
        alertReason.push('High BP');
    }
    
    // Stress Logic (High Stress warning)
    if (stress >= 4) {
        score -= 10;
        if(status !== 'danger') status = 'warning';
        alertReason.push('High Stress');
    }

    const dailyLog = {
        timestamp: timestamp,
        bp: `${bpSys || '--'}/${bpDia || '--'}`,
        heartRate: heartRate || '--',
        steps: steps || '--',
        sleep: sleep,
        stress: stress,
        weight: weight || '--',
        sugar: sugar || '--',
        symptoms: {
            chest: symChest,
            breath: symBreath,
            dizzy: symDizzy
        },
        score: score,
        status: status
    };

    // Save Alert if warning or danger
    if (status !== 'excellent') {
        const alert = {
            date: new Date().toLocaleDateString(),
            reason: alertReason.join(', '),
            score: score,
            status: status
        };
        let alerts = JSON.parse(localStorage.getItem('cardiosree_alerts') || '[]');
        alerts.push(alert);
        localStorage.setItem('cardiosree_alerts', JSON.stringify(alerts));
    }

    // Save history & latest
    let history = JSON.parse(localStorage.getItem('cardiosree_history') || '[]');
    history.push(dailyLog);
    localStorage.setItem('cardiosree_history', JSON.stringify(history));
    localStorage.setItem('cardiosree_latest', JSON.stringify(dailyLog));

    window.location.href = 'dashboard.html';
}

// Save Activity (Rehab Page)
function saveActivity() {
    const type = document.getElementById('activityType').value;
    const duration = document.getElementById('activityDuration').value;

    if (!duration) {
        alert('Please enter duration');
        return;
    }

    const activity = {
        type: type,
        duration: duration,
        timestamp: new Date().toISOString()
    };

    let activities = JSON.parse(localStorage.getItem('cardiosree_activities') || '[]');
    activities.push(activity);
    localStorage.setItem('cardiosree_activities', JSON.stringify(activities));

    alert('Activity Saved! ✅');
}

// Update Dashboard Vitals
function updateDashboardVitals() {
    const latest = JSON.parse(localStorage.getItem('cardiosree_latest'));
    
    // Calculate Risk Trend (Avg of last 7 entries)
    const history = JSON.parse(localStorage.getItem('cardiosree_history') || '[]');
    let trendScore = 100;
    if (history.length > 0) {
        const last7 = history.slice(-7);
        const sum = last7.reduce((acc, curr) => acc + (curr.score || 100), 0);
        trendScore = Math.round(sum / last7.length);
    }
    
    // Update Trend Display
    const trendEl = document.getElementById('trendScore');
    if (trendEl) trendEl.textContent = trendScore;

    if (!latest) return;

    const bpEl = document.getElementById('dashBP');
    const hrEl = document.getElementById('dashHR');
    const stepsEl = document.getElementById('dashSteps');
    
    if (bpEl) bpEl.textContent = latest.bp;
    if (hrEl) hrEl.textContent = latest.heartRate;
    if (stepsEl) stepsEl.textContent = latest.steps;
    
    const scoreCircle = document.querySelector('.score-circle');
    const statusTitle = document.querySelector('[data-i18n="status_excellent"]');
    const statusDesc = document.querySelector('[data-i18n="keep_it_up"]');

    if (scoreCircle && statusTitle && statusDesc) {
        scoreCircle.className = 'score-circle';
        
        if (latest.status === 'excellent') {
            scoreCircle.classList.add('score-green');
            scoreCircle.textContent = latest.score;
            statusTitle.setAttribute('data-i18n', 'status_excellent');
            statusTitle.textContent = translations[currentLang]['status_excellent'];
            statusDesc.setAttribute('data-i18n', 'keep_it_up');
            statusDesc.textContent = translations[currentLang]['keep_it_up'];
        } else if (latest.status === 'warning') {
            scoreCircle.classList.add('score-yellow');
            scoreCircle.textContent = latest.score;
            statusTitle.setAttribute('data-i18n', 'status_warning');
            statusTitle.textContent = translations[currentLang]['status_warning'];
            statusDesc.setAttribute('data-i18n', 'check_symptoms');
            statusDesc.textContent = translations[currentLang]['check_symptoms'];
        } else {
            scoreCircle.classList.add('score-red');
            scoreCircle.textContent = latest.score;
            statusTitle.setAttribute('data-i18n', 'status_danger');
            statusTitle.textContent = translations[currentLang]['status_danger'];
            statusDesc.setAttribute('data-i18n', 'seek_help');
            statusDesc.textContent = translations[currentLang]['seek_help'];
        }
    }
}

// Load Alert History (Alerts Page)
function loadAlertHistory() {
    const alerts = JSON.parse(localStorage.getItem('cardiosree_alerts') || '[]');
    const container = document.getElementById('alertList');
    
    if (!container) return;
    
    if (alerts.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:#999;" data-i18n="no_alerts">${translations[currentLang]['no_alerts']}</p>`;
        return;
    }
    
    container.innerHTML = '';
    // Show newest first
    alerts.reverse().forEach(alert => {
        const color = alert.status === 'danger' ? 'var(--danger)' : 'var(--accent)';
        const div = document.createElement('div');
        div.className = 'card';
        div.style.borderLeft = `5px solid ${color}`;
        div.innerHTML = `
            <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                <strong style="color:${color}">${alert.reason}</strong>
                <span style="font-size:12px; color:#666;">${alert.date}</span>
            </div>
            <div style="font-size:14px;">Heart Score: ${alert.score}</div>
        `;
        container.appendChild(div);
    });
}

// Logout
function logout() {
    localStorage.removeItem('cardiosree_profile');
    window.location.href = 'index.html';
}

// Export Data (CSV)
function exportData() {
    const profile = JSON.parse(localStorage.getItem('cardiosree_profile') || '{}');
    const history = JSON.parse(localStorage.getItem('cardiosree_history') || '[]');

    if (history.length === 0) {
        alert('No data to export!');
        return;
    }

    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Header
    csvContent += "Date,BP,Heart Rate,Steps,Weight,Sugar,Status\n";

    // Rows
    history.forEach(row => {
        csvContent += `${row.timestamp.split('T')[0]},${row.bp},${row.heartRate},${row.steps},${row.weight || '-'},${row.sugar || '-'},${row.status}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `CardioSree_Report_${profile.name || 'User'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
